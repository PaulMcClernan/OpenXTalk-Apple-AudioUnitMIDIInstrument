# lc-macos-toolset

This repo contains LiveCode Builder tests for APIs included with macOS. The code is useful as a starting off point for adding features to a LiveCode application or as a reference for how to accomplish various things in LiveCode Builder. For example, the WebKit code has examples of using Delegates.

LiveCode Builder Blog posts: https://livecode.com/tag/livecode-builder/

LiveCode Builder Widget Course: https://livecode.com/topic/introduction-2/
