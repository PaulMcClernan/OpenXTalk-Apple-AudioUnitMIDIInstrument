# frlGalleryPhotoHelper
This library will facilitate the process of creating an image gallery in LivCode.
